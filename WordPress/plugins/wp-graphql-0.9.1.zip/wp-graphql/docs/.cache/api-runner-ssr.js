var plugins = [{
      plugin: require('/Users/tyler/Documents/GitHub/wp-graphql/docs/node_modules/gatsby-plugin-manifest/gatsby-ssr'),
      options: {"plugins":[],"name":"wpgraphql-docs","short_name":"wpgraphql","start_url":"/","background_color":"#0E2339","theme_color":"#0E2339","display":"minimal-ui","icon":"source/images/icon.png"},
    },{
      plugin: require('/Users/tyler/Documents/GitHub/wp-graphql/docs/node_modules/gatsby-plugin-react-helmet/gatsby-ssr'),
      options: {"plugins":[]},
    },{
      plugin: require('/Users/tyler/Documents/GitHub/wp-graphql/docs/node_modules/gatsby-remark-autolink-headers/gatsby-ssr'),
      options: {"plugins":[]},
    },{
      plugin: require('/Users/tyler/Documents/GitHub/wp-graphql/docs/node_modules/gatsby-plugin-google-analytics/gatsby-ssr'),
      options: {"plugins":[],"trackingId":"UA-111783024-1"},
    },{
      plugin: require('/Users/tyler/Documents/GitHub/wp-graphql/docs/node_modules/gatsby-plugin-mdx/gatsby-ssr'),
      options: {"plugins":[],"gatsbyRemarkPlugins":[{"resolve":"gatsby-remark-typescript","options":{"wrapperComponent":"MultiCodeBlock"}},"gatsby-remark-autolink-headers",{"resolve":"gatsby-remark-copy-linked-files","options":{"ignoreFileExtensions":[]}},"gatsby-remark-prismjs-title",{"resolve":"gatsby-remark-prismjs","options":{"showLineNumbers":true}},"gatsby-remark-rewrite-relative-links",{"resolve":"gatsby-remark-check-links","options":{}}]},
    },{
      plugin: require('/Users/tyler/Documents/GitHub/wp-graphql/docs/node_modules/gatsby-theme-apollo-docs/gatsby-ssr'),
      options: {"plugins":[],"siteName":"WPGraphQL","menuTitle":"WPGraphQL","trackingId":"UA-111783024-1","algoliaApiKey":"fb8b4503ba2093d228a6c9b72facff9b","algoliaIndexName":"wpgraphql","baseUrl":"https://docs.wpgraphql.com","twitterHandle":"wpgraphql","spectrumHandle":"wpgraphql","youtubeUrl":"https://www.youtube.com/channel/UCwav5UKLaEufn0mtvaFAkYw","logoLink":"https://docs.wpgraphql.com","navConfig":{"wpgraphql.com":{"url":"https://www.wpgraphql.com","description":"The WPGraphQL homepage"},"WPGraphQL for ACF":{"url":"https://www.wpgraphql.com/acf/","description":"WPGraphQL for Advanced Custom Fields"},"Github":{"url":"https://github.com/wp-graphql","description":"WPGraphQL on Github"}},"footerNavConfig":{"Blog":{"href":"https://www.wpgraphql.com/blog/","target":"_blank","rel":"noopener noreferrer"},"Contribute":{"href":"/guides/contributing"}},"root":"/Users/tyler/Documents/GitHub/wp-graphql/docs","subtitle":"WPGraphQL","description":"WPGraphQL (GraphQL for WordPress) documentation.","githubRepo":"wp-graphql/wp-graphql","defaultVersion":0.4,"spectrumPath":"","sidebarCategories":{"null":["index"],"Getting Started":["getting-started/install-and-activate","getting-started/interacting-with-wpgraphql","getting-started/intro-to-graphql","getting-started/posts","getting-started/pages","getting-started/custom-post-types","getting-started/categories-and-tags","getting-started/custom-taxonomies","getting-started/custom-fields-and-meta","getting-started/users","getting-started/comments","getting-started/settings","getting-started/menus","getting-started/plugins","getting-started/themes"],"Extending":["extending/types","extending/fields","extending/connections","extending/mutations","extending/interfaces","extending/resolvers","extending/hooks-and-filters"],"Guides":["guides/about-wpgraphql","guides/the-graphql-query-language","guides/relay-spec","guides/connections","guides/anatomy-of-a-graphql-request","guides/upgrading","guides/authentication-and-authorization","guides/debugging","guides/deferred-resolvers","guides/query-batching","guides/contributing","guides/testing"],"Extensions":["extensions/all","extensions/building-an-extension","extensions/wpgraphql-woocommerce"]}},
    }]
// During bootstrap, we write requires at top of this file which looks like:
// var plugins = [
//   {
//     plugin: require("/path/to/plugin1/gatsby-ssr.js"),
//     options: { ... },
//   },
//   {
//     plugin: require("/path/to/plugin2/gatsby-ssr.js"),
//     options: { ... },
//   },
// ]

const apis = require(`./api-ssr-docs`)

// Run the specified API in any plugins that have implemented it
module.exports = (api, args, defaultReturn, argTransform) => {
  if (!apis[api]) {
    console.log(`This API doesn't exist`, api)
  }

  // Run each plugin in series.
  // eslint-disable-next-line no-undef
  let results = plugins.map(plugin => {
    if (!plugin.plugin[api]) {
      return undefined
    }
    const result = plugin.plugin[api](args, plugin.options)
    if (result && argTransform) {
      args = argTransform({ args, result })
    }
    return result
  })

  // Filter out undefined results.
  results = results.filter(result => typeof result !== `undefined`)

  if (results.length > 0) {
    return results
  } else {
    return [defaultReturn]
  }
}

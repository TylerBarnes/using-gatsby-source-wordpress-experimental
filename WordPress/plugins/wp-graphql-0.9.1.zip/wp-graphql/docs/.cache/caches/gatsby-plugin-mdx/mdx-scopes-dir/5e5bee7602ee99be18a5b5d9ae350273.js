import Note from "../../../../src/components/Note";
import GraphiQL from "../../../../src/components/GraphiQL";
import React from 'react';
export default {
  Note,
  GraphiQL,
  React
};
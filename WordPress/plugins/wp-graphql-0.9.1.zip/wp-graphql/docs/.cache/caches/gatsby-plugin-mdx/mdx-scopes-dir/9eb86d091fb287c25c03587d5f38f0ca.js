import GraphiQL from "../../../../src/components/GraphiQL";
import Note from "../../../../src/components/Note";
import React from 'react';
export default {
  GraphiQL,
  Note,
  React
};
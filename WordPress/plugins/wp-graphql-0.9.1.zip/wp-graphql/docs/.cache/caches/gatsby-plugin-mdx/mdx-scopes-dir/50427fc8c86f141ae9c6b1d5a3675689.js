import Note from "../../../../src/components/Note";
import React from 'react';
export default {
  Note,
  React
};
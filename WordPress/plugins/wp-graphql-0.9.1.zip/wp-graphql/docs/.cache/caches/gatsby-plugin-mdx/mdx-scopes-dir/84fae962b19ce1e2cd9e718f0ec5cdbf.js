import ExtensionsList from "../../../../src/components/ExtensionsList";
import Note from "../../../../src/components/Note";
import React from 'react';
export default {
  ExtensionsList,
  Note,
  React
};
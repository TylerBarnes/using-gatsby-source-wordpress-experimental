import GraphiQL from "../../../../src/components/GraphiQL";
import React from 'react';
export default {
  GraphiQL,
  React
};
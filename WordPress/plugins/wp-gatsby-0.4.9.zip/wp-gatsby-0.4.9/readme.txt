=== WPGatsby ===
Contributors: gatsbyinc, jasonbahl, tylerbarnes1
Tags: Gatsby, GatsbyJS, JavaScript, JAMStack, Static Site generator, GraphQL, Headless WordPress, Decoupled WordPress
Requires at least: 5.4
Tested up to: 5.4
Requires PHP: 7.1
Stable tag: 0.4.9
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

This plugin configures your WordPress site to be an optimized source for Gatsby.
See https://github.com/gatsbyjs/gatsby-source-wordpress-experimental for more info.

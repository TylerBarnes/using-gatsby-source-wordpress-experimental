<?php

namespace WPGatsby\ActionMonitor;

use WPGatsby\Admin\Settings;

class Dispatcher {
	/**
	 * Whether a build hook should be dispatched. Default false.
	 *
	 * @var bool
	 */
	protected $should_dispatch = false;

	public function __construct() {
		add_action( 'save_post_action_monitor', [ $this, 'queue_dispatch' ], 10, 3 );
		add_action( 'shutdown', [ $this, 'trigger_dispatch' ] );
	}

	/**
	 * @param $post_id int The ID of the Post being saved
	 * @param $post    \WP_Post The Post Object being saved
	 * @param $update  bool Whether this is an existing post being updated or not.
	 */
	public function queue_dispatch( $post_id, $post, $update ) {
		$this->should_dispatch = true;
	}

	public function trigger_dispatch() {
    // Gutenberg fires save_post twice. The first time it doesn't post anything.
    // interesting..
    if ( ! count( $_POST ) ) {
      return;
    }

    // We only want to dispatch if an action_monitor post has been created
    if ( ! $this->should_dispatch ) {
      return;
    }

    $webhook_field = Settings::prefix_get_option( 'builds_api_webhook', 'wpgatsby_settings', false );

		if ( $webhook_field ) {

      $webhooks = explode( ',', $webhook_field );

      foreach ( $webhooks as $webhook ) {
        wp_safe_remote_post( $webhook );
      }
		}
	}
}

# Data

Methods for reading and writing data should live here. The "DataSource" class serves as a factory for methods
that handle the fetching/writing of data.
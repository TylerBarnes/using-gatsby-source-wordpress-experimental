# WP Gatsby

This plugin configures your WordPress site to be an optimized source for Gatsby.
See https://github.com/gatsbyjs/gatsby-source-wordpress-experimental for more info.
